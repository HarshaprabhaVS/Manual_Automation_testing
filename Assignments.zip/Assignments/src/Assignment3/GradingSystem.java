package Assignment3;

import java.util.Scanner;

public class GradingSystem {

	public static void main(String[] args) {

		int num, maths;
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the value of num: ");
		num = sc.nextInt();
		System.out.print("Enter the value of maths: ");
		maths = sc.nextInt();

		if(num < 20)
		{
			System.out.println("Fail");
		}
		else if(num>=20 && num<40 && maths<20)
		{
			System.out.println("D");
			
		}
		else if(num>=40 && num<60 && maths>30)
		{
			System.out.println("C");
		}
		else if(num>=60 && num<80 && maths>60)
		{
			System.out.println("B");
		}
		else if(num>=80 && num<=100 && maths>80)
		{
			System.out.println("A");
		}
		else
		{
			System.out.println("No grade provided");
		}
		
	}

}
