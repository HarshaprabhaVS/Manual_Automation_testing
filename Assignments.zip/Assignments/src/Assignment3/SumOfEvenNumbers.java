package Assignment3;

public class SumOfEvenNumbers {

	public static void main(String[] args) {
		int i;
		int sum =0;
		for(i=2; i<=50;i++)
		{
			if(i%2==0)
			{
				sum = sum+i;
			}
		}
		System.out.println("Sum is "+sum);
	}

}
