package Assignment3;

import java.util.Scanner;

public class SimpleInterest {

	public static void main(String[] args) {
		int p,r,t;
		Scanner sc =new Scanner(System.in);
		
		System.out.println("Enter the principal amount: ");
		p= sc.nextInt();
		
		System.out.println("Enter the rate of interest: ");
		r= sc.nextInt();
		
		System.out.println("Enter the time: ");
		t= sc.nextInt();
		
		int SI = (p*r*t)/100;
		System.out.println("Simple Interest is: "+SI);
		
	}

}
