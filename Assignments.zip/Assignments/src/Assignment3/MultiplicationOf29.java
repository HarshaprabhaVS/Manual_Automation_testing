package Assignment3;

public class MultiplicationOf29 {

	public static void main(String[] args) {
		int num=29;
		int i=1;
		while(i<=10) 
		{
			System.out.println(num + "*" +i +"=" +(num*i));
			i++;
		}
	}
}
