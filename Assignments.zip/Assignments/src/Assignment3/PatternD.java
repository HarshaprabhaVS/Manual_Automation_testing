package Assignment3;

public class PatternD {

	public static void main(String[] args) {
		int i,j;

		for(i=1;i<=5;i++)
		{
			char ch ='A';
			for(j=1;j<=i;j++)
			{
				System.out.print(ch);
				ch++;

			}
			System.out.println();
		}

	}

}


