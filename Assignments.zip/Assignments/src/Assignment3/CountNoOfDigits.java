package Assignment3;

public class CountNoOfDigits {

	public static void main(String[] args) {
		int count = 0;
		int num = 34577;
		while(num!=0)
		{
			num=num/10;
			count++;		
		}
		System.out.println("Number of digits in an Integer is: "+count);
	}
}
