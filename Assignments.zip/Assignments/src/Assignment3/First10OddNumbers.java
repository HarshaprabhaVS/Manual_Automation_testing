package Assignment3;

public class First10OddNumbers {

	public static void main(String[] args) {
		int i;
		for(i=1;i<=10;i++)
		{
			if(i%2 !=0)
			{
				System.out.println(i);
			}
		}

	}

}
