package Assignment3;

import java.util.Scanner;

public class PositiveOrNegative {

	public static void main(String[] args) {
		int i;
		System.out.println("Enter the number: ");
		Scanner sc=new Scanner(System.in);
		i=sc.nextInt();
		if(i>0)
		{
			System.out.println("Positive");
		}
		else if(i<0)
		{
			System.out.println("Negative");
		}
		else
		{
			System.out.println("zero");
		}
	}

}
