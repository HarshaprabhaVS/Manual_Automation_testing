package Assignment3;

public class RectangleOrSquare {

	public static void main(String[] args) {
		
		
		int length =4;
		int breadth=4;
		
		if(length == breadth)
		{
			System.out.println("It is a Square");
		}
		else
		{
			System.out.println("It is a Rectangle");
		}
	}

}
