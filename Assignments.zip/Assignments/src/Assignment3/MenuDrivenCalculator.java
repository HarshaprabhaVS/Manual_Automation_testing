package Assignment3;

import java.util.Scanner;

public class MenuDrivenCalculator {

	public static void main(String[] args) {
		int n1,n2,sum,subtract,multiple,divide;
		System.out.println("Enter the number n1: ");		
		Scanner sc=new Scanner(System.in);		
		n1=sc.nextInt();

		System.out.println("Enter the number n2: ");
		Scanner sc2=new Scanner(System.in);
		n2=sc2.nextInt();
		
		System.out.println("Choose the operator: ");
		Scanner sc3=new Scanner(System.in);
		String operator =sc3.nextLine();
		switch(operator) 
		{
		case "+":
			sum=n1+n2;
			System.out.println("Sum is "+sum);
			break;
		case "-":
			subtract=n1-n2;
			System.out.println("Subtraction is "+subtract);
			break;
		case "*":
			multiple=n1*n2;
			System.out.println("Multiplication is "+multiple);
			break;
		case "/":
			divide=n1/n2;
			System.out.println("Division is "+divide);
			break;	
		}
	}
}
